# Track review summary

- Reconstructed length: **1765.1 m**
- Complete laps: **17**
- Valid evidence laps: **14**
- Declared physical features: **41**
- Accepted speed gates: **12**
- Recommended review: **24**
- Must fix: **0**

Gate confidence is an evidence score, not a probability that a gate is true. The component scores expose the supporting pass count, speed repeatability, braking evidence, pace independence, coordinate quality, and cross-vehicle agreement.

## Recommended review

- **Turn 1** (52.6/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Turn 2** (41.1/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Bump 4** (46.9/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Turn 5** (54.8/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Bump 6** (57.9/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Turn 7** (52.7/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Banked Turn** (50.6/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Turn 10** (56.7/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Slaloms 11** (55.6/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Compound: Turn 12 + Slaloms 13 + Turn 14** (53.7/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Hills 15** (53.8/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Bumps 20** (50.5/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Ruts 21** (48.0/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Big Hill** (58.7/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Hill/Tires** (46.5/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Compound: Drop + Turn 27** (53.2/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Turn 28** (57.7/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Hills 29** (41.8/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Ruts 30** (47.6/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Turn 35** (57.7/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Compound: Ruts 38 + Turn 39** (47.6/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Pipe 40** (51.4/100) — Move the entry measurement window or verify that this event genuinely constrains speed.
- **Hole** (55.6/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.
- **Long Pit** (51.2/100) — Review whether the event belongs in a compound response group or has inconsistent entry placement.

## Accepted gates with retained assumptions

- **Long Hill** — Gate evidence is accepted, but retain/review the declared assumptions: response group extent very long.
- **Crazy Ruts** — Gate evidence is accepted, but retain/review the declared assumptions: response group extent very long.
- **Long Hill 25** — Gate evidence is accepted, but retain/review the declared assumptions: response group extent very long.
- **Bumps 32** — Gate evidence is accepted, but retain/review the declared assumptions: response group extent very long.
- **Tires 34** — Gate evidence is accepted, but retain/review the declared assumptions: response group extent very long.

## Excluded laps

- Lap 1 (arizona_endurance_1): excessive_stationary_fraction
- Lap 7 (arizona_endurance_1): path_distance_outlier;excessive_stationary_fraction;p95_map_error_exceeds_limit
- Lap 14 (arizona_endurance_3): path_distance_outlier;excessive_stationary_fraction;sampling_gap;large_backward_map_match;p95_map_error_exceeds_limit

## Review order

1. Resolve all `must_fix` coordinate or contract problems.
2. Inspect `recommended_review` events against video and the map.
3. Confirm response groups for adjacent or overlapping physical features.
4. Treat accepted gate speeds as empirical distributions, not exact constants.
5. Do not infer road grade from the raw elevation profile yet.
