# Decision trace

1. **Question** — What is lost because the declared ideal CVT has finite ratio bounds?
2. **Observed nominal time penalty** — 0.0114 s.
3. **Observed nominal opportunity loss** — 0.4766 kJ.
4. **Reference dominance check** — `True`.
5. **Numerically valid** — `True`.
6. **Evidence ready** — `False`.
7. **Decision ready** — `False`.
8. **Interpretation** — This establishes a nominal mechanism comparison, not a robust design ranking.
9. **Constraints on interpretation**
   - Track review contains 24 event(s) still recommended for review.
   - Track evidence contains one vehicle identity; cross-vehicle agreement is not measured.
   - Track evidence contains one driver identity; cross-driver agreement is not measured.
   - This is one nominal scenario, so it does not quantify track or model uncertainty.
   - The infinite-ratio result is a counterfactual opportunity bound, not a realizable drivetrain.
