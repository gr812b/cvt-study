# Nominal bounded-CVT baseline report

This report starts with the engineering comparison and then links to the trace-level evidence. The infinite-ratio case removes finite ratio bounds while preserving the same vehicle, track evidence, driver gates, and launch contract.

## 1. Result

| Metric | Bounded ideal CVT | Infinite-ratio reference | Difference |
| --- | ---: | ---: | ---: |
| Lap time [s] | 168.7065 | 168.6951 | +0.0114 |
| Average speed [km/h] | 37.666 | 37.668 | -0.003 |
| Opportunity loss [kJ] | 1.065 | 0.588 | +0.477 |

## 2. Numerical quality

| Check | Result |
| --- | --- |
| Both cases completed | `True` |
| Reference dominance | `True` |
| Accepted-gate compliance | `True` |
| Vehicle energy closure | `True` (9.577e-06) |
| Powertrain energy closure | `True` (2.317e-03) |

A failed quality check overrides an attractive performance number.

## 3. Evidence readiness

Evidence ready: `False`. Decision ready: `False`.

| Evidence check | Result |
| --- | --- |
| Project validation warnings | 0 |
| Track events accepted | 12 |
| Track events recommended for review | 24 |
| Track events marked must-fix | 0 |
| Run identities | 2 |
| Vehicle identities | 1 |
| Driver identities | 1 |

A numerically valid run remains exploratory while project-input or track-review warnings are unresolved.

## 4. Physical energy accounting

These rows are physical loss channels. Finite-ratio opportunity loss is counterfactual and is deliberately not added to this balance.

| Component | Bounded [kJ] | Reference [kJ] |
| --- | ---: | ---: |
| Drivetrain efficiency | 0.000 | 0.000 |
| Launch clutch | 0.591 | 0.588 |
| Tire slip | 56.248 | 56.388 |
| Braking | 175.401 | 175.508 |
| Rolling resistance | 121.169 | 121.169 |
| Aerodynamic drag | 82.304 | 82.332 |
| Obstacles | 699.455 | 699.453 |

Feature-level obstacle energy is in [obstacle_energy_by_feature.csv](obstacle_energy_by_feature.csv).

## 5. Ratio occupancy and trace evidence

The bounded case spent 33.277 s at minimum reduction, 0.932 s at maximum reduction, and 134.498 s in the variable-ratio region.

Use [01_speed_comparison.png](01_speed_comparison.png), [02_ratio_trace.png](02_ratio_trace.png), and the two trace CSV files to inspect where the comparison was created.

## 6. Gate behavior

[gate_compliance.csv](gate_compliance.csv) records every accepted measured speed gate, its target, the two simulated speeds, and the compliance tolerance.

## 7. Warnings and scope

- Track review contains 24 event(s) still recommended for review.
- Track evidence contains one vehicle identity; cross-vehicle agreement is not measured.
- Track evidence contains one driver identity; cross-driver agreement is not measured.
- This is one nominal scenario, so it does not quantify track or model uncertainty.
- The infinite-ratio result is a counterfactual opportunity bound, not a realizable drivetrain.
- Telemetry elevation is screened, but grade force remains disabled pending a material paired sensitivity.
- The current tire model is longitudinal and intentionally compact.
- The bounded ideal CVT is an intentionally reduced-order comparison mechanism.

## 8. Provenance

The exact evidence bundle, resolved inputs, run identity, and hashes are recorded in `track_bundle.json`, `resolved_inputs/`, `run_manifest.json`, `provenance.json`, and [provenance_graph.svg](provenance_graph.svg).

## 9. Appendix

The [appendix index](appendix/README.md) maps this report to all machine-readable outputs.
