# Machine-readable appendix

- `../bounded_summary.json` and `../infinite_reference_summary.json` — scalar case outputs
- `../comparison_summary.json` — finite-ratio deltas and dominance check
- `../bounded_trace.csv` and `../infinite_reference_trace.csv` — trace-level state and energy history
- `../gate_compliance.csv` — measured-gate targets and simulated compliance
- `../obstacle_energy_by_feature.csv` — feature-level energy accounting
- `../resolved_simulation_case.json` — fully resolved mechanism inputs
- `../run_manifest.json` — run identity and numerical quality
- `../provenance.json` — version, command, and evidence hashes
- `../track_bundle.json` and `../track_bundle.sha256` — exact Track Evidence Bundle
- `../resolved_inputs/` — complete resolved project configuration
