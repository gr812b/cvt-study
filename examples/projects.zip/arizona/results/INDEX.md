# Result index

Completed framework results discovered below this directory.

| Created (UTC) | Study | Type | Numerical | Evidence | Decision ready | Result |
| --- | --- | --- | --- | --- | --- | --- |
| 2026-07-19T04:30:55.042094+00:00 | baseline | baseline | valid | review required | no | [baseline/20260719T043004Z](baseline/20260719T043004Z/SUMMARY.md) |
